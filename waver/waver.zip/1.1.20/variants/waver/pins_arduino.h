/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  $Id: wiring.h 249 2007-02-03 16:52:51Z mellis $
*/

/*
	This version of pins_arduino.h is for the Waver 1.0 r1
	Jaewoo Kim  2014 July 3
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#define NUM_DIGITAL_PINS            15
#define NUM_ANALOG_INPUTS           2
//#define analogInputToDigitalPin(p)  (((p) >12) ? (p) - 13 : -1
#define analogPinToChannel(p)  (((p) >12) ? (p) - 13 : -1)

#define digitalPinHasPWM(p)         ((p) < 9 )  

const static uint8_t SS   = 8;
const static uint8_t SCK  = 15;
const static uint8_t MOSI = 16;
const static uint8_t MISO = 17;

const static uint8_t SDA = 12;
const static uint8_t SCL = 11;
const static uint8_t LED = 20;

const static uint8_t A0 = 13;
const static uint8_t A1 = 14;


const static uint8_t RFTX = 23;
const static uint8_t RFRX = 24;


#define digitalPinToPCICR(p)   ( ( ((p)==1) || ((p)==2) || ((p)==3) || ((p)==4) || ((p)==8) || ((p)==15) || ((p)==16) || ((p)==17) || ((p)==18)  ) ? (&PCICR) : ((uint8_t *)0) )
#define digitalPinToPCICRbit(p) (  ((p) < 18) ? 0 :1 )
#define digitalPinToPCMSK(p)    ( ((p) < 18) ? (&PCMSK0) : ((p) == 19) ? (&PCMSK1) : ((uint8_t *)0) )
#define digitalPinToPCMSKbit(p) ( ((p) == 8) ? 0 : \
                                 ((p) == 15) ? 1 : \
                                 ((p) == 16) ? 2 : \ 
                                 ((p) == 17) ? 3 : \
                                 ((p) == 4)  ? 4 : \
                                 ((p) == 3)  ? 6 : \
                                 ((p) == 2)  ? 5 : \
                                 ((p) == 1)  ? 7 : \
                                 ((p) == 18) ? 0 : \
                                  0 )   


#ifdef ARDUINO_MAIN

const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	(uint16_t)&DDRA,
	(uint16_t)&DDRB,
	(uint16_t)&DDRC,
	(uint16_t)&DDRD,
	(uint16_t)&DDRE,
	(uint16_t)&DDRF,
	(uint16_t)&DDRG,
	NOT_A_PORT,
	NOT_A_PORT,
	NOT_A_PORT,
	NOT_A_PORT,
	NOT_A_PORT,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	(uint16_t)&PORTA,
	(uint16_t)&PORTB,
	(uint16_t)&PORTC,
	(uint16_t)&PORTD,
	(uint16_t)&PORTE,
	(uint16_t)&PORTF,
	(uint16_t)&PORTG,
	NOT_A_PORT,
	NOT_A_PORT,
	NOT_A_PORT,
	NOT_A_PORT,
	NOT_A_PORT,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PIN,
	(uint16_t)&PINA,
	(uint16_t)&PINB,
	(uint16_t)&PINC,
	(uint16_t)&PIND,
	(uint16_t)&PINE,
	(uint16_t)&PINF,
	(uint16_t)&PING,
	NOT_A_PIN,
	NOT_A_PIN,
	NOT_A_PIN,
	NOT_A_PIN,
	NOT_A_PIN,
};

//	waver 3.0
//
//  NO	Name	PORT	ETC
//
//	 0	PWM1	PB7
//	 1	PWM2	PG5		PCINT7
//	 2	PWM3	PB5		PCINT6
//	 3	PWM4	PB6		PCINT5
//	 4	PWM5	PB4		PCINT4
//	 5	PWM6	PE3
//	 6	PWM7	PE4
//	 7	PWM8	PE5
//   8  SS		PB0		PCINT0
//	 9	TX1		PD3
//	10	RX1		PD2
//	11	SCL		PD0
//	12	SDA		PD1
//	13	A0		PF0
//	14	A1		PF1
//	15	SCK		PB1		PCINT1
//	16	MOSI	PB2		PCINT2
//	17	MISO	PB3		PCINT3
//	18	RX0		PE0		PCINT8	
//  19	TX0		PE1
//  20	LED		PE5




const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
	// PORTLIST		
	PB,		// 0 PWM1	PB7
	PG,		// 1 PWM2	PG5
	PB,		// 2 PWM3	PB5
	PB,		// 3 PWM4	PB6
	PB,		// 4 PWM5	PB4
	PE,		// 5 PWM6	PE3
	PE,		// 6 PWM7	PE4
	PE,		// 7 PWM8	PE5
	PB,		// 8 SS		PB0
	PD,		// 9 TX1	PD3
	PD,		// 10 RX1	PD2
	PD,		// 11 SCL	PD0
	PD,		// 12 SDA	PD1
	PF,		// 13 A0	PF0
	PF,		// 14 A1	PF1
	PB,		// 15 SCK	PB1
	PB,		// 16 MOSI	PB2
	PB,		// 17 MISO  PB3
	PE,		// 18 RX0	PE0
	PE,		// 19 TX0	PE1
	PE,		// 20 LED	PE5


};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
	// PIN IN PORT		
	// -------------------------------------------		
	_BV(7)	, // 0
	_BV(5)	, // 1
	_BV(5)	, // 2
	_BV(6)	, // 3
	_BV(4)	, // 4
	_BV(3)	, // 5
	_BV(4)	, // 6
	_BV(5)	, // 7
	_BV(0)	, // 8
	_BV(3)	, // 9
	_BV(2)	, // 10
	_BV(0)	, // 11
	_BV(1)	, // 12
	_BV(0)	, // 13
	_BV(1)	, // 14	
	_BV(1)	, // 15	
	_BV(2)	, // 16	
	_BV(3)	, // 17	
	_BV(0)	, // 18	
	_BV(1)	, // 19
	_BV(5)	, // 20



};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
	// TIMERS		
	// -------------------------------------------	
	TIMER0A	,	// 0
	TIMER0B	,	// 1	
	TIMER1A	,	// 2
	TIMER1B	,	// 3
	TIMER2A	,	// 4
	TIMER3A	,	// 5
	TIMER3B	,	// 6
	TIMER3C	,	// 7
	NOT_ON_TIMER	, // 8
	NOT_ON_TIMER	, // 9
	NOT_ON_TIMER	, // 10
	NOT_ON_TIMER	, // 11	
	NOT_ON_TIMER	, // 12	
	NOT_ON_TIMER	, // 13
	NOT_ON_TIMER	, // 14
	NOT_ON_TIMER	, // 15
	NOT_ON_TIMER	, // 16
	NOT_ON_TIMER	, // 17
	NOT_ON_TIMER	, // 18
	NOT_ON_TIMER	, // 19
	TIMER3C			, // 20	
			
};	

#endif

#endif